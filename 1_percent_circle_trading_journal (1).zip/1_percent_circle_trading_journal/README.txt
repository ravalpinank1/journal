# 1% Circle · Trading Journal

## Run
1. Extract the ZIP file.
2. Open `index.html` in a modern browser (Chrome, Edge, Firefox, etc.).
3. An internet connection is needed to load Chart.js and Font Awesome from their CDNs.

## Data
Trade entries and theme preferences are stored in the browser's localStorage for this browser/profile. Clearing browser data may remove saved trades.

## Included
- Responsive trading journal dashboard
- Profit/loss trade entry form
- Account selection (Account 1–3)
- Statistics, distribution chart, calendar, and trade history
- Dark/light theme toggle
